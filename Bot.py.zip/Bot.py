from selenium import webdriver
from selenium.webdriver import Chrome


from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from time import sleep 

import os

import random
from random import randint




from selenium.webdriver.chrome.service import Service

from selenium import webdriver
from selenium.webdriver.common.by import By
from time import sleep
# import requests
import os
import datetime
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options




class InstagramBot:

	def __init__(self,username,password):
		self.username = username
		self.password = password

		#full path of your chromedriver
		self.driver_web_browser = webdriver.Chrome('/Users/JohnDoe/Downloads/chromedriver')
		self.links = []
		self.hashtags = [ 'Trump','dog','daddybear','babydaddy','stormi','coco','skims','beastly','minicooper','tesla' ]
		self.comments = ['Sweet!','Amazing!','Greatness!','AwsomeNESS','Beast!','Beastly!','too Beast!']

		self.sleep_time = random.randint(18,28)

		self.login()
		self.get_top_posts()
		print(self.links)
		self.execute_like_and_comment() # OR self.comment_sneakier_hybrid()


	def login(self):
		self.driver_web_browser.get('https://instagram.com/accounts/login')
		sleep(2)
		username = self.driver_web_browser.find_element_by_css_selector('#loginForm > div > div:nth-child(1) > div > label > input').send_keys(self.username)
		sleep(2)
		password = self.driver_web_browser.find_element_by_css_selector('#loginForm > div > div:nth-child(2) > div > label > input').send_keys(self.password)
		sleep(2)
		click = self.driver_web_browser.find_element_by_css_selector('#loginForm > div > div:nth-child(3) > button > div').click()
		sleep(3)
		not_now = self.driver_web_browser.find_element_by_css_selector('#react-root > section > main > div > div > div > div > button').click()
		sleep(3)
		no_notification = self.driver_web_browser.find_element_by_css_selector('body > div.RnEpo.Yx5HN > div > div > div > div.mt3GC > button.aOOlW.HoLwm').click()
		sleep(3)


	def get_top_posts(self):
		for hashtag in self.hashtags:
			self.driver_web_browser.get('https://instagram.com/explore/tags/'+hashtag+'/')
			sleep(2)

			links = self.driver_web_browser.find_elements_by_tag_name('a')
			condition = lambda link: '.com/p' in link.get_attribute('href') #filter out invalid links//
			valid_links = list(filter(condition , links))

			for i in range(0,9):# getting 10 links
				link = valid_links[i].get_attribute('href')
				if link not in self.links:
					self.links.append(link)


	def execute_like_and_comment(self):
		for link in self.links:
			self.driver_web_browser.get(link)

			#like
			self.driver_web_browser.find_element_by_xpath('//*[@id="react-root"]/section/main/div/div[1]/article/div[3]/section[1]/span[1]/button').click()
			sleep(3)

			#comment
			self.driver_web_browser.find_element_by_class_name('RxpZH').click()
			sleep(1)
			self.driver_web_browser.find_element_by_xpath("//textarea[@placeholder='Add a comment…']").send_keys(self.comments[randint(0,6)])
			sleep(2)
			self.driver_web_browser.find_element_by_xpath("//button[@type='submit']").click()
			sleep(2)



	def comment_sneakier_hybrid(self):
		for link in self.links:
			self.driver_web_browser.get(link)
			#like
			self.driver_web_browser.find_element_by_xpath('//*[@id="react-root"]/section/main/div/div[1]/article/div[3]/section[1]/span[1]/button').click()
			sleep(3)

		self.driver_web_browser.find_element_by_class_name('RxpZH').click()
		sleep(2)
		click = self.driver_web_browser.find_element_by_xpath("//textarea[@placeholder='Add a comment…']")

		comment = random.choice(self.comments)
		for letter in comment:
			click.send_keys(letter)
			delay = random.randint(1,7)/30
			sleep(delay)

		self.driver_web_browser.find_element_by_xpath("//button[@type='submit']").click()
		sleep(self.sleep_time)


bot = InstagramBot('YourEmail@gmail.com','Password123')